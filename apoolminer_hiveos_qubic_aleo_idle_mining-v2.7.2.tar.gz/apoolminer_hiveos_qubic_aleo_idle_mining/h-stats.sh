#!/usr/bin/env bash

source h-manifest.conf
source /hive/miners/custom/apoolminer_hiveos_qubic_aleo_idle_mining/apoolminer_hiveos_qubic_aleo_idle_mining.conf
algo=$(grep 'META' /hive-config/wallet.conf | awk -F '=' '{print $2}' | tr -d '"' | sed -n 's/.*coin:\([^}]*\).*/\1/p' | tr '[:upper:]' '[:lower:]')
stats=""
khs=0

if [[ "$algo" == "qubic" ]]; then
    # Qubic 
    gpus_raw=$(curl -s --connect-timeout 3 --max-time 5 http://127.0.0.1:5001/gpu)

    if [[ $? -ne 0 || -z $gpus_raw ]]; then
        echo -e "${RED}Failed to get gpus info from 127.0.0.1:5001/gpu${NOCOLOR}"
    else
        data=$(echo "$gpus_raw" | jq -cr '.data')
        readarray -t temp_data < <(echo "$data" | jq -cr '.uptime, ([.gpus[].proof]|add/1000), [.gpus[].proof], [.gpus[].ctmp], [.gpus[].fan], ([.gpus[].valid]|add), ([.gpus[].inval]|add), [.gpus[].bus] ' 2>/dev/null)

        unit="it"
        uptime="${temp_data[0]/s/}"
        khs="${temp_data[1]}"
        khs=$(echo $khs | sed -E 's/^( *[0-9]+\.[0-9]([0-9]*[1-9])?)0+$/\1/')
        hs="${temp_data[2]}"
        temp="${temp_data[3]}"
        fan="${temp_data[4]}"
        accepted="${temp_data[5]}"
        rejected="${temp_data[6]}"
        bus_numbers="${temp_data[7]}"
        version="$CUSTOM_VERSION"

        stats=$(jq -nc --arg khs "$khs" \
                       --argjson hs "$hs" \
                       --arg hs_units "$unit" \
                       --argjson temp "$temp" \
                       --argjson fan "$fan" \
                       --arg accepted "$accepted" \
                       --arg rejected "$rejected" \
                       --arg uptime "$uptime" \
                       --arg ver "$version" \
                       --arg algo "$algo" \
                       --argjson bus_numbers "$bus_numbers" \
                       '{$hs, "hs_units": $hs_units, 
                         $temp, $fan, "ar": [$accepted | tonumber, $rejected | tonumber], $bus_numbers,
                         "uptime": $uptime | tonumber | floor, $ver, $algo}')

        echo "$stats"
    fi
elif [[ "$algo" == "aleo" ]]; then
    # Aleo 
    CUSTOM_VERSION=$(grep "apool"  /var/log/miner/apoolminer_hiveos_qubic_aleo_idle_mining/apoolminer_hiveos_qubic_aleo_idle_mining.log | awk '{for(i=1;i<=NF;i++) if($i=="apool") {print $(i+1); exit}}')
    version="$CUSTOM_VERSION"
    log=/var/log/miner/apoolminer_hiveos_qubic_aleo_idle_mining/apoolminer_hiveos_qubic_aleo_idle_mining.log

    #  zkminer  PID
    zkminer_pid=$(pgrep -f zkminer)
    if [ -z "$zkminer_pid" ]; then
        echo "zkminer process not found."
        uptime=0
    else
        CLK_TCK=$(getconf CLK_TCK)
        stat_file="/proc/$zkminer_pid/stat"
        starttime=$(awk '{print $22}' "$stat_file")
        uptime=$(awk '{print $1 * '$CLK_TCK'}' /proc/uptime)
        uptime=$(echo "scale=2; ($uptime - $starttime) / $CLK_TCK" | bc)
    fi

    bus_numbers_hex=$(lspci | grep -i nvi | awk '{print $1}' | cut -d: -f1 | sort | uniq)
    bus_numbers_dec=()
    for bus in $bus_numbers_hex; do
        bus_dec=$((16#$bus))
        bus_numbers_dec+=($bus_dec)
    done

    gpus=$(tail -50 "$log" | egrep -i 'MiB|NVIDIA' | awk -F'|' '{print $2}' | sort | uniq | wc -l)
    lines=$(($gpus + 1))
    data=$(tail -30 "$log" | grep Total -B "$gpus" | tail -"${lines}")
#    echo "$data"

    gpu_ids=()
    hs=()
    solutions=()
    memories=()
    devices=()

    while IFS= read -r line; do
        line=$(echo "$line" | sed 's/^ *| *//;s/ *| *$//')

        [[ -z "$line" || "$line" =~ ^-+ ]] && continue

        IFS='|' read -r -a fields <<< "$line"

        for i in "${!fields[@]}"; do
            fields[$i]=$(echo "${fields[$i]}" | sed 's/^ *//;s/ *$//')
        done

        if [[ "${fields[0]}" =~ ^[0-9]+$ ]]; then
            gpu_ids+=("${fields[0]}")
            hs+=("${fields[1]}")
            solutions+=("${fields[2]}")
            memories+=("${fields[3]}")
            devices+=("${fields[4]}")
        elif [[ "${fields[0]}" == "Total" ]]; then
            rates="${fields[1]}"
            total_solutions="${fields[2]}"
        fi
    done <<< "$data"

    for i in ${gpu_ids[*]}; do
       temperature=$(nvidia-smi -i "$i" --query-gpu=temperature.gpu --format=csv,noheader,nounits)
       fan_speed=$(nvidia-smi -i "$i" --query-gpu=fan.speed --format=csv,noheader,nounits)
       gpu_temperatures+=($temperature)
       gpu_fan_speeds+=($fan_speed)
    done
    khs=$(echo "scale=2; $rates / 1000" | bc)

#    echo "GPU IDs: ${gpu_ids[*]}"
#    echo "Rates: ${rates[*]}"
#    echo "Solutions: ${solutions[*]}"
#    echo "Memories: ${memories[*]}"
#    echo "Devices: ${devices[*]}"
#    echo "bus_numbers_dec: ${bus_numbers_dec[*]}"
#    echo "khs: $khs"
#    echo "Total Solutions: $total_solutions"
#    echo "gpu_temperatures: ${gpu_temperatures[*]}"
#    echo "gpu_fan_speeds: ${gpu_fan_speeds[*]}"
#    echo "zkminer running time: $uptime seconds"

    stats=$(jq -nc --argjson gpu_ids "$(printf '%s\n' "${gpu_ids[@]}" | jq -R . | jq -s .)" \
                  --argjson hs "$(printf '%s\n' "${hs[@]}" | jq -R . | jq -s . | jq 'map(tonumber)')" \
                  --argjson solutions "$(printf '%s\n' "${solutions[@]}" | jq -R . | jq -s . | jq 'map(tonumber)')" \
                  --argjson memories "$(printf '%s\n' "${memories[@]}" | jq -R . | jq -s .)" \
                  --argjson devices "$(printf '%s\n' "${devices[@]}" | jq -R . | jq -s .)" \
                  --argjson bus_numbers "$(printf '%s\n' "${bus_numbers_dec[@]}" | jq -R . | jq -s . | jq 'map(tonumber)')" \
                  --argjson temp "$(printf '%s\n' "${gpu_temperatures[@]}" | jq -R . | jq -s . | jq 'map(tonumber)')" \
                  --argjson fan "$(printf '%s\n' "${gpu_fan_speeds[@]}" | jq -R . | jq -s . | jq 'map(tonumber)')" \
                  --arg hs_units "hs" \
                  --arg ver "$version" \
                  --arg algo "$algo" \
                  --arg khs "$khs" \
                  --arg total_solutions "$total_solutions" \
                  --arg uptime "$uptime" \
                  '{khs: $khs | tonumber, gpu_ids: $gpu_ids, hs: $hs, solutions: $solutions, temp: $temp, fan: $fan, memories: $memories, devices: $devices, hs_units: $hs_units, ver: $ver, algo: $algo, total_solutions: $total_solutions | tonumber, bus_numbers: $bus_numbers, uptime: $uptime | tonumber}')

    echo "$stats"
else
    echo "Unknown algorithm: $algo"
fi
